
# __init__.py under localization module

from .localization_accessibility import LocalizationAccessibility

__all__ = ['LocalizationAccessibility']
