
# __init__.py under ui directory

from .ui_design import UIDesign
