
# __init__.py under config module

from .config_handler import ConfigHandler

__all__ = ['ConfigHandler']
