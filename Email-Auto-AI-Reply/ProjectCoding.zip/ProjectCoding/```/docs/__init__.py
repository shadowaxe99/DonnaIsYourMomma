
"""
This is the __init__.py file for the docs module.
It doesn't contain any code. Its presence indicates that 'docs' is a package.
"""
