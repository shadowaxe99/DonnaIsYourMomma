
# __init__.py under threading module

from .multi_threading import start_threads
