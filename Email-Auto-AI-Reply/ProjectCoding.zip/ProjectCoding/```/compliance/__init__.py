
# __init__.py under compliance module

from .compliance_licensing import ComplianceLicensing

__all__ = ['ComplianceLicensing']
