
# __init__.py under extendibility module

# This file is required to make Python treat the directories as containing packages

from .extendibility_modularity import ExtendibilityModularity
