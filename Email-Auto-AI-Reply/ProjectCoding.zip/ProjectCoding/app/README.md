# Email-Auto-AI-Reply

## Notice

This bot will automatically reply ALL emails in your inbox with AI response, and automatically permanently delete ALL emails which it has replied. So it is AT YOUR RISK to run this code. For your own good, I suggest you open a new email account to test this bot. ALL AI responses are generated from chatterbot package and are NOT ACCURATE and SHOULD NOT BE TRUSTED in replying important emails. 

## How to run it

You need to pip install the package called chatterbot

https://github.com/gunthercox/ChatterBot

LICENSE&Notification for this package please see license.txt

You need to replace the account (has to be gmail account) and passward part in EmailAutoReply.py 

You need to at least have one email in your inbox when running this bot, and this bot will keeping running unless you manually stop it.

You need to write emails to the account you used in the code and it will automatically reply to you

## Have fun with this email bot!!!
